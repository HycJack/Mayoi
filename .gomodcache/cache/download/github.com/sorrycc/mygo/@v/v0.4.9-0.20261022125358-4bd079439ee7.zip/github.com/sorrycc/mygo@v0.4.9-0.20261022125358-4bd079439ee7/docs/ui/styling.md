# Styling and themes

`Background`, `Border`, `Radius`, `Shadow` and `Opacity` style an
element's box, and `Cursor` sets the pointer over it:

```go
ui.Column(c).Padding(18).Gap(12).Radius(10).
	Background(t.Background).Border(1, t.Border).
	Shadow(0, 1, 3, 0, ui.RGBA(0, 0, 0, 0.06))
```

- **Borders.** `Border(1, c)` draws one inside every edge; `BorderWidth`
  sets the sides apart, CSS style, with `BorderColor`, as a line under a
  header with `BorderWidth(0, 0, 1, 0)`, and `BorderStyle(ui.BorderDashed)`
  dashes it. As with CSS's `box-sizing: border-box`, the border takes room
  within the element's size, and the padding and the children are inside
  it.
- **Shadows.** `Shadow(x, y, blur, spread, c)` casts a box shadow, as CSS's
  `box-shadow` does: several stack, and each shows only outside the box,
  so a translucent background never shows its own shadow through.
  `InsetShadow(x, y, blur, spread, c)` draws an inner one, as
  `box-shadow: inset`: inside the box's padding edge, within its border
  and rounded corners, above the background and below the children; the
  offset moves it, and a positive spread grows it inward. Inner shadows
  stack too, and go with outer ones, as a hairline that edges a field in
  the dark:

  ```go
  field.Radius(12).Background(t.Surface).
  	Shadow(0, 8, 24, 0, ui.RGBA(0, 0, 0, 0.3)).
  	InsetShadow(0, 0, 1, 0, ui.RGBA(255, 255, 255, 0.2))
  ```
- **Gradients and stripes.** `Gradient(from, to, angle)` fills the box with
  a linear gradient; `LinearGradient` also places its colors along the line
  (`Start`, `End`) and mixes them in Oklab, which keeps their lightness,
  instead of sRGB, or takes as many colors as its `Stops`, each a
  `GradientStop{Color, At}` at its place from 0 to 1. `ConicGradient` turns
  its stops around a point instead, as CSS's `conic-gradient()` (SwiftUI's
  `AngularGradient`): from `Angle`, in degrees clockwise from upwards,
  around `Center`, the middle unless set. `BorderLinearGradient` and
  `BorderConicGradient` paint the border with one in place of its color,
  as SwiftUI's `strokeBorder` with a gradient:

  ```go
  rainbow := []ui.GradientStop{{red, 0}, {yellow, 0.33}, {blue, 0.66}, {red, 1}}
  ui.Box(c).Size(120, 80).Radius(16).Border(4, ui.Color{}).
  	BorderConicGradient(ui.ConicGradient{Stops: rainbow, Oklab: true})
  ```

  `Stripes(c, width, gap, angle)` draws stripes over the background, as on
  what is unavailable. A painter fills rectangles and paths with the same
  gradients (`FillGradient`, `FillConicGradient`, `FillPathGradient`,
  `FillPathConicGradient`, `StrokePathConicGradient`).
- **Blur.** `Blur(sigma)` blurs the element and its children, as CSS's
  `filter: blur()`: what they draw spreads about 3 sigma DIPs around,
  transparent beyond, on the GPU. They render into a bitmap first, as an
  [effect](shaders.md#effects-on-elements) does, every frame they paint;
  clicks, focus and assistive technology take the element where it is.
  Glows are borders blurred, a sharp one and blurred ones stacked:

  ```go
  for _, l := range []struct{ width, blur float32 }{{6, 0}, {9, 4}, {15, 15}} {
  	ui.Box(c).Absolute().Top(0).Left(0).Right(0).Bottom(0).PassThrough().
  		Radius(16).Border(l.width, ui.Color{}).BorderConicGradient(glow).Blur(l.blur)
  }
  ```
- **Materials.** `Material(m)` fills the box with a material a package
  paints, in place of a background, as the [glass
  plugin](../plugins/glass.md)'s Liquid Glass, which what is under it shows
  through, frosted and bent along its edges, its scroll edges and its
  backdrop blur, which may fade along a gradient.
- **Pointer.** `Cursor` takes the shapes of the platforms: `CursorPointer`,
  `CursorText`, `CursorMove`, `CursorGrab` and `CursorGrabbing`, the
  resize cursors (both ways, toward one side as `CursorResizeE`, and of
  columns and rows), `CursorCopy` and `CursorAlias` for drops,
  `CursorContextMenu`, `CursorVerticalText`, `CursorNotAllowed`,
  `CursorCrosshair`, and `CursorNone`, which hides it. An element's
  cursor shows over its children too, except over those that take clicks
  (a button, or anything with `Clicked` or `OnClick`): those show their
  own, the default arrow unless they set one, so the buttons of a field
  with `CursorText` show no I-beam.

`ui.Oklch(l, c, h)` is CSS's `oklch()`; `.Alpha(a)` is its `/ a`. It
returns a `ui.Color` like any other, so fills, borders, gradients,
stripes, shadows, dividers, text, decorations, text backgrounds, the
glass's tint and the theme (`t.Accent = ui.Oklch(0.6, 0.2, 240)`) all take
it. It can name colors outside sRGB, more vivid than most screens show.
Such a color keeps both: its real value, drawn when the window is on a
screen that shows a wider range (Display P3 on recent Macs), and the
nearest sRGB color, chosen as CSS does (less saturated, same lightness and
hue). That fallback is its `R`, `G` and `B`, and is what sRGB screens,
Linux, Windows and SVG pictures draw; `SRGB()` returns it without the real
value. `Mix` and transitions mix the real values: a mix back inside sRGB
is an ordinary color. Don't assign `R`, `G` or `B` of such a color, as the
real value would no longer match: make a new one.

Colors come from `ui.RGB`, `ui.RGBA` and `ui.Hex("#2563eb")`; `Mix` blends
two, and `Alpha` makes one translucent.

## State, not selectors

There are no style sheets and no state selectors: the view is code, so an
element's look follows the state in the view itself, as
`if row.Hovered() { row.Background(t.SurfaceHover) }`, and one element's
state can style another, as a group's hover does in CSS.

A widget returns its element, so a call after it styles it differently
from the rest: `ui.Button(c, "Save").Padding(10, 20).Radius(999)`. For a
look of your own, build on the widgets' bases, which have none: see
[custom widgets](custom-widgets.md).

## Themes

Widgets take their colors and metrics from the theme, `c.Theme()`: the
light or the dark theme, following the system's appearance as it changes,
and the settings of the desktop that the system's own controls follow. Use
its colors in your own elements so they follow too. To change it, set a
copy:

```go
t := *c.Theme() // the default, which follows the system
t.Accent, t.Radius = ui.Hex("#7c3aed"), 8
t.Spacing = 3 // compact
c.SetTheme(&t)
```

`Spacing` is the unit of the room widgets leave: their paddings and gaps,
and the sizes of check boxes, switches, sliders and the rows of tables and
trees, are multiples of it. It is 4 by default; 3 makes every widget
compact, 5 roomy. `FontSize` sizes their text, `Radius` rounds their
corners, and `ScrollbarWidth` sets the width of scroll bars. On macOS,
rounded corners, the widgets' and your elements', curve continuously as
AppKit's and SwiftUI's do, and elsewhere as quarter circles, as Windows
and GTK draw them. Size your own
elements with the theme too, and they follow it: `t.Space(3)` is three
units of its spacing, and `t.Rem(2)` twice its font size, as CSS's rem.

Tooltips and toasts are the theme turned over, so that they stand out from
what they are over: filled with `Inverse`, with `InverseText` on it, which
left zero are the theme's `Text` and `Background`. A dark app that would
rather keep them dark sets both:

```go
t.Inverse, t.InverseText = ui.Hex("#3f3f46"), ui.Hex("#fafafa")
```

## The desktop's preferences

`c.Preferences()` returns the settings of the desktop, which the default
theme follows and a frame follows the changes of:

- **`Accent`.** The accent color the user chose (macOS, Windows, and
  desktops whose portal gives one, as GNOME 47 and KDE do), which colors
  primary buttons, the choice and the focus ring, with text on it that
  stands out.
- **`HighContrast`.** macOS's Increase Contrast, Windows's contrast themes,
  the portal's higher contrast: borders and secondary text are darker
  (lighter in the dark), and the focus ring opaque.
- **`TextScale`.** Windows's and GNOME's text size: `FontSize` is that many
  times larger.
- **`ReduceMotion`.** macOS's Reduce Motion, Windows's animation effects and
  GNOME's animations turned off: `Animate` goes to its target at once.
